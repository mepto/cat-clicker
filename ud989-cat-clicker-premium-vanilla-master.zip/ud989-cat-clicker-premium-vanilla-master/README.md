# Cat Clicker Premium Vanilla

Here's Ben's solution for Cat Clicker Premium from [Udacity's Javascript Design Patterns course](https://www.udacity.com/course/javascript-design-patterns--ud989).

Clone the repo and open up `index.html` in your browser of choice.
